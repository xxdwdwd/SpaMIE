"""
SpaMIE - A wonderful Python package
"""
__version__ = "0.1.0"
__author__ = "Xiang dw"


from .preprocess import *
from .create_graph import *
from .spamie_main import *
from .spamie_net import *


